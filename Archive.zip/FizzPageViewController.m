//
//  FizzPageViewController.m
//  Fizz
//
//  Created by Daze Corp on 18/07/15.
//  Copyright (c) 2015 DazeCorp. All rights reserved.
//
#import "FizzPageViewController.h"

@interface FizzPageViewController ()

@end


@implementation FizzPageViewController;

@synthesize fizzinfobackgroundImageView;

@synthesize fizzloginUiIimage;

@synthesize imageFile;
@synthesize logimageFile;

@synthesize pageIndex;
@synthesize finninfolabel;
@synthesize titleText;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg"]]];
    self.fizzinfobackgroundImageView.image = [UIImage imageNamed:self.imageFile];
    self.finninfolabel.text = self.titleText;
    self.fizzloginUiIimage.image=[UIImage imageNamed:self.logimageFile];
    //finninfolabel.textAlignment = NSTextAlignmentCenter;
      NSLog(@"%s", "FizzPageViewController - ViewDidload");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

